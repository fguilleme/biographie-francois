# Chronologie provisoire

> Cette chronologie est un document de travail. Les dates marquées « environ » devront être vérifiées.

## Années 1970

- **1972–1973** — Sixième au collège Saint-Louis ; pensionnaire à Saint-Clément, situé à environ cent mètres du collège. Assez bon élève.
- **1973–1974** — Cinquième au collège Saint-Louis ; toujours pensionnaire à Saint-Clément. Assez bon élève.
- **1974–1975** — Quatrième au collège Saint-Louis ; François n'est plus pensionnaire et vit chez ses parents. Mauvaise année scolaire.
- **1975–1976** — Troisième à l'École Centrale d'Électronique, rue de la Lune à Paris. Assez bon élève, motivé par l'électronique.
- **1976–1977** — Seconde dans un établissement catholique de Saint-Brieuc, probablement Saint-Charles – La Providence ; internat dans une annexe du séminaire située de l'autre côté de la rue. François reste volontairement juste à la moyenne.
- **1977–1978** — Première F1 au Lycée de Montgeron, près du domicile familial.
- **Vers 1978** — Premiers programmes sur une calculatrice **TI-57**, limitée à 49 instructions.
- Passage ultérieur à une calculatrice Hewlett-Packard programmable, modèle à confirmer.
- En classe préparatoire, accès aux **Tandy TRS-80** du lycée, parfois en entrant par la fenêtre du local informatique.
- Achat d’un ordinateur **DAI** avec le salaire de deux mois de travail d’été comme ramoneur.
- Premiers programmes en assembleur sur le DAI, en apprenant directement avec la documentation Intel du 8080.
- **Été 1978** — Nouvelle-Calédonie, une semaine à Wallis, puis séjour à Melbourne en Australie.
- **Décembre 1978** — Projet de voyage en Thaïlande abandonné à cause d'un problème de visa lié au changement d'escale ; séjour d'environ cinq jours à Istanbul à la place.
- **1978–1979** — Terminale F1, construction mécanique, au Lycée de Montgeron. François travaille très peu, pense pouvoir rater le bac et envisage alors de s'engager dans la Marine. Il obtient néanmoins, selon son souvenir, 17 en mathématiques, 16 en gammes d'usinage et 12 en mécanique.
- À l'épreuve de gammes d'usinage, François termine très rapidement et doit attendre les trente minutes réglementaires avant de sortir. Il rapproche cette matière de la programmation : ordonner correctement une suite d'étapes.
- **Été 1979** — Pérou, chemin de l'Inca jusqu'au Machu Picchu, puis retour anticipé en France.
- **19 septembre 1979** — Permis de conduire, trois jours après ses dix-huit ans.

## 1979–1983 — Études, nucléaire et service militaire

- **1979–1981 environ** — Mathématiques supérieures puis mathématiques spéciales dans une filière destinée aux titulaires d'un baccalauréat technique ; établissement transcrit oralement comme « l'EST », à identifier. François est un bon élève, dans le peloton de tête en mathématiques et en physique.
- **1980 environ** — Travail d'été comme ramoneur ; le salaire de deux mois permettra ensuite l'achat d'un ordinateur DAI.
- **1981–1982 environ** — Formation à Cadarache : BTS de contrôle des rayonnements ionisants et applications techniques de protection, intitulé exact à vérifier.
- **1982** — Stage de fin d'études au SMSR, puis incorporation à Creil en août pour environ six semaines de classes.
- **1982–juillet 1983** — Service militaire au SMSR dans un environnement essentiellement civil. Travail de laboratoire sur la détection indirecte du plutonium 239.
- **Pendant le service** — Mission d'environ six semaines à Mururoa, au moment où un cyclone venait de frapper Tahiti ; date exacte à établir.
- **Juillet 1983** — Fin du service militaire et achat à crédit d'une Volkswagen Scirocco neuve, gris métallisé.
- **1983, environ trois mois** — Poste lié à l'usine de retraitement de La Hague, logement à Cherbourg, puis démission.
- **Fin 1983** — Retour en région parisienne après La Hague.
- **Fin 1983 / début 1984** — Formation informatique orientée gestion, rémunérée à environ 80 % de l'ancien salaire ; dates et organisme à confirmer.
- **Janvier 1984** — Grave accident de voiture avec la Volkswagen Scirocco ; date précise à confirmer.
- **1984** — Activités ponctuelles pour CBS autour du Coleco Adam.
- **1984** — Stage de six semaines chez LINCS, puis CDI.
- **1984** — Départ de LINCS après environ cinq mois.
- **Fin décembre 1984** — Départ pour un voyage de cinq mois par les États-Unis, le Mexique et le Guatemala.

## 1984–1985 — Mexique, Guatemala et États-Unis

- Voyage par New York, La Nouvelle-Orléans, Laredo, Mexico, Puebla, Puerto Ángel, Oaxaca, Mérida, Chichén Itzá et Palenque.
- Entrée au Guatemala depuis la côte pacifique du Mexique, par un poste-frontière non identifié.
- Arrêt à San Francisco El Alto, puis arrivée au lac Atitlán.
- Passage bref à Panajachel, puis séjour d'environ trois semaines à San Pedro La Laguna.
- Remontée vers le Mexique, puis vers les États-Unis.
- Train vers le nord après une étape probablement située à Aguascalientes ; nom à confirmer.
- Passage de la frontière américaine, à une gare qui reste à identifier.
- Reprise du stop à El Paso, passage exact à vérifier, puis traversée de l'Arizona et du Nouveau-Mexique avant l'arrivée à San Diego.
- Séjour à San Francisco à l'European Guest House, près de Market Street.
- **31 mai 1985** — Retour en France le matin de l'anniversaire du père de François. Le voyage a duré exactement cinq mois et constitue alors son plus long voyage.
- Récit détaillé : [Guatemala et remontée vers les États-Unis](voyages/1984-guatemala-remontee-etats-unis.md).

## 1985–1986 — Djinntel, médecine et Chine

- **Été 1985** — Pour rembourser son découvert, François trouve à l'ANPE une offre improbable de programmeur assembleur 8080 et entre chez **Djinntel**.
- Il travaille environ trois mois en assembleur 8080, enseigne le langage C au reste de l'équipe et rencontre brièvement Henri Seydoux, consultant.
- Le soir, il programme en 6502 sur Oric et développe **Nibble**, éditeur de disquettes comportant un mode piste pilotant directement le contrôleur de disque.
- **Automne 1985** — Entrée en première année de médecine, décision née de la rencontre avec Claude au Mexique.
- François a vingt-quatre ans, échoue par manque de travail et redouble.
- **Été 1986** — Départ pour la Chine, sans préparation détaillée, avec le projet de rejoindre Lhassa, Katmandou, Varanasi puis New Delhi.
- Environ trois semaines à Pékin avec un étudiant anglais en anthropologie ; ce séjour débloque son aisance en anglais.
- Passage par Xi'an et l'armée de terre cuite, puis Xining et Golmud.
- Arrivée à Lhassa ; séjour d'environ trois semaines dans une guest house rudimentaire, visites répétées du Potala et leçon d'anglais improvisée à un moine.
- Bus affrété par des routards vers le Népal ; traversée d'environ une semaine, point culminant vers 5 600 mètres.
- Passage par Katmandou, Varanasi, Agra et New Delhi.
- Trois jours à l'aéroport de New Delhi, avec trois samoussas par jour, avant de pouvoir embarquer comme passager compagnie.
- Retour en France et réinscription en première année de médecine pour redoubler.
- **Noël 1986** — Dernier billet passager compagnie et séjour à Rio de Janeiro, durée probablement proche de vingt jours mais non confirmée.
- Récits détaillés : [Chine, Tibet, Népal et Inde](voyages/1986-chine-tibet-nepal-inde.md) et [Rio de Janeiro](voyages/1986-rio-de-janeiro.md).

## Premiers voyages

- **À 14 ans et 10 mois** — Voyage seul en auto-stop jusqu’en Bretagne pour rejoindre un ami et sa famille. Trois semaines sans donner de nouvelles ; la mère de François demande finalement à la poste du village de vérifier qu’il va bien.
- Après ce séjour, visite à un oncle vivant à environ 100 km. François est envoyé directement dans la baignoire ; l’eau devient noire.
- **À 15 ans et 10 mois** — Premier grand voyage seul dans l’océan Indien : île Maurice, La Réunion et Seychelles, avec environ 100 francs en poche.

## Années 1980 — Informatique

- **Été 1985** — Travail de quelques mois chez **Djinntel**, dirigée par Jean-Pierre Talvard.
- Programmation professionnelle en assembleur 8080 sur un serveur Minitel ; programmation personnelle en 6502 sur Oric le soir.
- François est le seul de l'équipe à connaître le langage C et l'enseigne à ses collègues.
- Rencontre d’Henri Seydoux chez Djinntel ; leurs chemins se recroiseront près de vingt ans plus tard chez Parrot, en 2003.
- Développement de **Nibble** sur Oric, publié par Informatique et Nature.
- **1986–1990 environ** — Développements sur Atari ST : **SuperFormat**, **Expander**, **Twist**, utilitaires disque et pilote de grand écran.
- Collaboration comme pigiste avec **ST Magazine**, en tant que développeur proche de la rédaction.
- **Twist** est distribué notamment par **HiSoft** au Royaume-Uni et par Upgrade Éditions en France.

## À documenter ensuite

- Suite du séjour à Rio et retour à la médecine.
- Afrique du Sud.
- Israël.
- Voyages en Asie, Afrique et Amérique latine.
- Parcours professionnel ultérieur et Parrot.
- Identifier précisément l'établissement de prépa transcrit « l'EST ».
- Stabiliser la chronologie Cadarache–stage SMSR–service militaire–Mururoa.

## Référence scolaire

- [Chronologie scolaire de référence](meta/chronologie-scolaire-reference.md)
